export const environment = {
  production: true,
  apiUrl: '/api' // adjust when deployed behind same domain
};

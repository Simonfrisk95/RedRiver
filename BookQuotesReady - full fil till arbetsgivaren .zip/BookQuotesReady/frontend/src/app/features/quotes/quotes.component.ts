import { Component } from '@angular/core';

@Component({
  templateUrl: './quotes.component.html'
})
export class QuotesComponent {
  quotes: string[] = JSON.parse(localStorage.getItem('quotes') || '[]');
  quote = '';

  add() {
    if (this.quote.trim()) {
      this.quotes.unshift(this.quote.trim());
      this.quotes = this.quotes.slice(0, 5);
      this.save();
      this.quote = '';
    }
  }

  remove(idx: number) {
    this.quotes.splice(idx, 1);
    this.save();
  }

  private save() {
    localStorage.setItem('quotes', JSON.stringify(this.quotes));
  }
}

import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

interface Book {
  id: number;
  title: string;
  author: string;
  published: string;
}

@Component({
  templateUrl: './book-list.component.html'
})
export class BookListComponent implements OnInit {
  books: Book[] = [];
  import { environment } from '../../../environments/environment';

  private api = environment.apiUrl + '/books';

  constructor(private http: HttpClient, private router: Router) { }

  ngOnInit() {
    this.load();
  }

  load() {
    this.http.get<Book[]>(this.api).subscribe(b => this.books = b);
  }

  add() {
    this.router.navigate(['/books/new']);
  }

  edit(book: Book) {
    this.router.navigate(['/books', book.id, 'edit']);
  }

  delete(book: Book) {
    if (confirm('Radera boken?')) {
      this.http.delete(`${this.api}/${book.id}`).subscribe(() => this.load());
    }
  }
}

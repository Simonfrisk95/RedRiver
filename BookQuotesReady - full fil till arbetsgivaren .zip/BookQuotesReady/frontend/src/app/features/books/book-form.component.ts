import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

interface Book {
  id?: number;
  title: string;
  author: string;
  published: string;
}

@Component({
  templateUrl: './book-form.component.html'
})
export class BookFormComponent implements OnInit {
  form = this.fb.group({
    id: [0],
    title: ['', Validators.required],
    author: ['', Validators.required],
    published: ['', Validators.required]
  });
  import { environment } from '../../../environments/environment';

  private api = environment.apiUrl + '/books';
  isEdit = false;

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private router: Router, private http: HttpClient) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.http.get<Book>(`${this.api}/${id}`).subscribe(b => this.form.patchValue(b));
    }
  }

  save() {
    const book = this.form.value as Book;
    if (this.isEdit) {
      this.http.put(`${this.api}/${book.id}`, book).subscribe(() => this.router.navigate(['/books']));
    } else {
      this.http.post(this.api, book).subscribe(() => this.router.navigate(['/books']));
    }
  }
}

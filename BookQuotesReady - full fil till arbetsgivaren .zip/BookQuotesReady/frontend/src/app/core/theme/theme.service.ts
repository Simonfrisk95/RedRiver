import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private current = localStorage.getItem('theme') || 'light';

  constructor() {
    document.documentElement.setAttribute('data-theme', this.current);
  }

  toggleTheme() {
    this.current = this.current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', this.current);
    localStorage.setItem('theme', this.current);
  }

  get isDark() {
    return this.current === 'dark';
  }
}

import { Component } from '@angular/core';
import { AuthService } from '../auth/auth.service';
import { ThemeService } from '../theme/theme.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html'
})
export class NavbarComponent {
  constructor(public auth: AuthService, public theme: ThemeService) { }

  toggleTheme() {
    this.theme.toggleTheme();
  }
}

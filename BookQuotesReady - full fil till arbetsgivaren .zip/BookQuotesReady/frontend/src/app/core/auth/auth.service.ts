import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AuthService {
  import { environment } from '../../../environments/environment';

  private api = environment.apiUrl + '/auth';

  constructor(private http: HttpClient) { }

  login(userName: string, password: string) {
    return this.http.post<{ token: string }>(`${this.api}/login`, { userName, password })
      .pipe(tap(res => localStorage.setItem('token', res.token)));
  }

  logout() {
    localStorage.removeItem('token');
  }

  get token(): string | null {
    return localStorage.getItem('token');
  }

  get isLoggedIn(): boolean {
    return !!this.token;
  }
}

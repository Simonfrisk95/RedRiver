namespace BookQuotes.Api.DTOs
{
    public record LoginResponse(string Token);
}

namespace BookQuotes.Api.DTOs
{
    public record LoginRequest(string UserName, string Password);
}
